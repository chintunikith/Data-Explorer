
function Header() {
    return (
        <div>
            <h1 className="title">Clinical Trials</h1>
        </div>
    );
}

export default Header